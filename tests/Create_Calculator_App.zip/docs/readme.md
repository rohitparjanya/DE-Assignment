Simple Calculator App
======================
### Overview

The Simple Calculator App is a basic arithmetic calculator implemented in Python. It provides a simple command-line interface for performing addition, subtraction, multiplication, and division operations.

### Installation

To use the Simple Calculator App, you need to have Python installed on your system. You can download the latest version of Python from the official Python website.

1. **Clone the repository**: Clone the repository containing the calculator code using Git.
2. **Navigate to the directory**: Navigate to the directory where the calculator code is located.
3. **Run the calculator**: Run the calculator using the command `python calculator.py`.

### Usage

To use the Simple Calculator App, follow these steps:

1. **Run the calculator**: Run the calculator using the command `python calculator.py`.
2. **Choose an operation**: Choose an operation from the menu by entering the corresponding number (1-5).
3. **Enter numbers**: Enter the numbers for the operation.
4. **View result**: The calculator will display the result of the operation.

### Operations

The Simple Calculator App supports the following operations:

* **Addition**: Adds two numbers.
* **Subtraction**: Subtracts one number from another.
* **Multiplication**: Multiplies two numbers.
* **Division**: Divides one number by another.

### API Reference

#### Calculator Class

The `Calculator` class provides methods for performing arithmetic operations.

##### Methods

* **`add(num1: float, num2: float) -> float`**: Adds two numbers.
	+ Args:
		- `num1 (float)`: The first number.
		- `num2 (float)`: The second number.
	+ Returns:
		- `float`: The sum of `num1` and `num2`.
* **`subtract(num1: float, num2: float) -> float`**: Subtracts one number from another.
	+ Args:
		- `num1 (float)`: The first number.
		- `num2 (float)`: The second number.
	+ Returns:
		- `float`: The difference between `num1` and `num2`.
* **`multiply(num1: float, num2: float) -> float`**: Multiplies two numbers.
	+ Args:
		- `num1 (float)`: The first number.
		- `num2 (float)`: The second number.
	+ Returns:
		- `float`: The product of `num1` and `num2`.
* **`divide(num1: float, num2: float) -> float`**: Divides one number by another.
	+ Args:
		- `num1 (float)`: The dividend.
		- `num2 (float)`: The divisor.
	+ Returns:
		- `float`: The quotient of `num1` and `num2`.
	+ Raises:
		- `ZeroDivisionError`: If `num2` is zero.

### Example Use Cases

* **Addition**: `calculator.add(2, 3)` returns `5`.
* **Subtraction**: `calculator.subtract(5, 2)` returns `3`.
* **Multiplication**: `calculator.multiply(4, 5)` returns `20`.
* **Division**: `calculator.divide(10, 2)` returns `5`.

### Troubleshooting

* **Invalid input**: If you enter a non-numeric value, the calculator will display an error message.
* **Division by zero**: If you attempt to divide by zero, the calculator will raise a `ZeroDivisionError`.