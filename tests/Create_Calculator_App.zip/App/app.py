Here's a Streamlit UI code that can be easily integrated with the given calculator application:

```python
# calculator_streamlit.py

import streamlit as st
from calculator import Calculator

def main():
    """
    The main function that runs the Streamlit calculator app.
    """
    calculator = Calculator()

    st.title("Simple Calculator App")

    with st.sidebar:
        choice = st.selectbox("Choose an operation", ["Addition", "Subtraction", "Multiplication", "Division"])

    if choice == "Addition":
        num1 = st.number_input("Enter the first number")
        num2 = st.number_input("Enter the second number")
        if st.button("Calculate"):
            result = calculator.add(num1, num2)
            st.write(f"{num1} + {num2} = {result}")

    elif choice == "Subtraction":
        num1 = st.number_input("Enter the first number")
        num2 = st.number_input("Enter the second number")
        if st.button("Calculate"):
            result = calculator.subtract(num1, num2)
            st.write(f"{num1} - {num2} = {result}")

    elif choice == "Multiplication":
        num1 = st.number_input("Enter the first number")
        num2 = st.number_input("Enter the second number")
        if st.button("Calculate"):
            result = calculator.multiply(num1, num2)
            st.write(f"{num1} * {num2} = {result}")

    elif choice == "Division":
        num1 = st.number_input("Enter the first number")
        num2 = st.number_input("Enter the second number")
        if st.button("Calculate"):
            try:
                result = calculator.divide(num1, num2)
                st.write(f"{num1} / {num2} = {result}")
            except ZeroDivisionError as e:
                st.error(str(e))

if __name__ == "__main__":
    main()
```

This code creates a simple Streamlit app with a sidebar that allows the user to choose an operation. Based on the chosen operation, the app prompts the user to enter two numbers and then calculates the result when the "Calculate" button is clicked.

To run this app, save the `calculator.py` file (your original code) and the `calculator_streamlit.py` file (the code above) in the same directory. Then, run the following command in your terminal:

```bash
streamlit run calculator_streamlit.py
```

This will launch the Streamlit app in your default web browser.