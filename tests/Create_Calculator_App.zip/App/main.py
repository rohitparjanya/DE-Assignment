# calculator.py

class Calculator:
    """
    A simple calculator class with basic arithmetic operations.
    """

    def __init__(self):
        """
        Initialize the calculator.
        """
        pass

    def add(self, num1: float, num2: float) -> float:
        """
        Add two numbers.

        Args:
            num1 (float): The first number.
            num2 (float): The second number.

        Returns:
            float: The sum of num1 and num2.
        """
        return num1 + num2

    def subtract(self, num1: float, num2: float) -> float:
        """
        Subtract num2 from num1.

        Args:
            num1 (float): The first number.
            num2 (float): The second number.

        Returns:
            float: The difference between num1 and num2.
        """
        return num1 - num2

    def multiply(self, num1: float, num2: float) -> float:
        """
        Multiply two numbers.

        Args:
            num1 (float): The first number.
            num2 (float): The second number.

        Returns:
            float: The product of num1 and num2.
        """
        return num1 * num2

    def divide(self, num1: float, num2: float) -> float:
        """
        Divide num1 by num2.

        Args:
            num1 (float): The dividend.
            num2 (float): The divisor.

        Returns:
            float: The quotient of num1 and num2.

        Raises:
            ZeroDivisionError: If num2 is zero.
        """
        if num2 == 0:
            raise ZeroDivisionError("Cannot divide by zero")
        return num1 / num2


def main():
    """
    The main function that runs the calculator app.
    """
    calculator = Calculator()

    while True:
        print("\nSimple Calculator App")
        print("1. Addition")
        print("2. Subtraction")
        print("3. Multiplication")
        print("4. Division")
        print("5. Quit")

        choice = input("Choose an operation (1-5): ")

        if choice == "5":
            print("Goodbye!")
            break

        elif choice in ["1", "2", "3", "4"]:
            try:
                num1 = float(input("Enter the first number: "))
                num2 = float(input("Enter the second number: "))

                if choice == "1":
                    result = calculator.add(num1, num2)
                    print(f"{num1} + {num2} = {result}")

                elif choice == "2":
                    result = calculator.subtract(num1, num2)
                    print(f"{num1} - {num2} = {result}")

                elif choice == "3":
                    result = calculator.multiply(num1, num2)
                    print(f"{num1} * {num2} = {result}")

                elif choice == "4":
                    try:
                        result = calculator.divide(num1, num2)
                        print(f"{num1} / {num2} = {result}")
                    except ZeroDivisionError as e:
                        print(str(e))

            except ValueError:
                print("Invalid input. Please enter a number.")

        else:
            print("Invalid choice. Please choose a valid operation.")


if __name__ == "__main__":
    main()