**Deployment Configuration for Simple Calculator App**

To deploy the simple calculator app, we will use a containerization approach with Docker, a CI/CD pipeline with GitHub Actions, and infrastructure as code (IaC) with Terraform. We will also implement monitoring and logging practices using Prometheus and Grafana.

### Recommended Deployment Strategies

1. **Containerization**: Use Docker to containerize the calculator app, ensuring consistency and portability across different environments.
2. **CI/CD Pipeline**: Implement a CI/CD pipeline using GitHub Actions to automate testing, building, and deployment of the app.
3. **Infrastructure as Code (IaC)**: Use Terraform to manage and provision infrastructure resources, such as virtual machines and networks.
4. **Monitoring and Logging**: Use Prometheus and Grafana to monitor and log app performance and errors.

### CI/CD Pipeline Setup and Tools

We will use GitHub Actions to set up a CI/CD pipeline for the calculator app. The pipeline will consist of the following steps:

1. **Test**: Run unit tests and integration tests for the app.
2. **Build**: Build the Docker image for the app.
3. **Deploy**: Deploy the app to a production environment using Terraform.

**`.github/workflows/deploy.yml`**
```yml
name: Deploy Calculator App

on:
  push:
    branches:
      - main

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout code
        uses: actions/checkout@v2

      - name: Test
        run: |
          python -m unittest discover -s tests

      - name: Build
        run: |
          docker build -t calculator-app .

      - name: Deploy
        uses: hashicorp/terraform-github-actions@v1.2.0
        with:
          terraform_version: '1.1.9'
          args: 'apply -auto-approve'
```

### Infrastructure as Code (IaC) Configurations

We will use Terraform to manage and provision infrastructure resources for the calculator app. The IaC configuration will consist of the following resources:

1. **Virtual Machine**: Create a virtual machine to run the calculator app.
2. **Network**: Create a network to connect the virtual machine to the internet.
3. **Docker Container**: Create a Docker container to run the calculator app.

**`main.tf`**
```terraform
provider "aws" {
  region = "us-west-2"
}

resource "aws_instance" "calculator_app" {
  ami           = "ami-0c94855ba95c71c99"
  instance_type = "t2.micro"
  vpc_security_group_ids = [aws_security_group.calculator_app.id]
}

resource "aws_security_group" "calculator_app" {
  name        = "calculator_app"
  description = "Security group for calculator app"

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "docker_container" "calculator_app" {
  name  = "calculator_app"
  image = "calculator-app:latest"
  ports = ["80:80"]
}
```

### Monitoring and Logging Practices

We will use Prometheus and Grafana to monitor and log app performance and errors.

**`prometheus.yml`**
```yml
global:
  scrape_interval: 10s

scrape_configs:
  - job_name: 'calculator_app'
    scrape_interval: 10s
    static_configs:
      - targets: ['localhost:80']
```

**`grafana.ini`**
```ini
[server]
http_port = 3000

[security]
admin_password = admin
```

### Deployment Configuration File

The deployment configuration file will consist of the following sections:

1. **App Configuration**: Configure the calculator app.
2. **Docker Configuration**: Configure the Docker container.
3. **Terraform Configuration**: Configure the Terraform IaC configuration.
4. **Prometheus Configuration**: Configure the Prometheus monitoring configuration.
5. **Grafana Configuration**: Configure the Grafana logging configuration.

**`deployment_config.yml`**
```yml
app:
  name: calculator_app
  port: 80

docker:
  image: calculator-app:latest
  container_name: calculator_app

terraform:
  config_file: main.tf
  state_file: terraform.tfstate

prometheus:
  config_file: prometheus.yml
  scrape_interval: 10s

grafana:
  config_file: grafana.ini
  http_port: 3000
```

### Actionable Steps

1. Create a new GitHub repository for the calculator app.
2. Create a new file called `calculator.py` and add the calculator app code.
3. Create a new file called `.github/workflows/deploy.yml` and add the CI/CD pipeline configuration.
4. Create a new file called `main.tf` and add the Terraform IaC configuration.
5. Create a new file called `prometheus.yml` and add the Prometheus monitoring configuration.
6. Create a new file called `grafana.ini` and add the Grafana logging configuration.
7. Create a new file called `deployment_config.yml` and add the deployment configuration.
8. Run the CI/CD pipeline using GitHub Actions.
9. Verify that the calculator app is deployed and running correctly.
10. Monitor and log app performance and errors using Prometheus and Grafana.